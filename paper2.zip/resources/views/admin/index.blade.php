@extends('admin.layouts.admin')

@section('title', '领取纸巾')

@section('content')
    <iframe id="J_iframe" width="100%" height="100%" src="index_v1.html?v=4.0" frameborder="0" data-id="index_v1.html" seamless></iframe>
    @endsection