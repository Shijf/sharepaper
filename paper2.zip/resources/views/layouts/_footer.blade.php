<div class="weui-footer">
    <p class="weui-footer__links">
        <a href="http://jqweui.com" class="weui-footer__link">jQuery-WeUI 首页</a>
    </p>
    <p class="weui-footer__text">Copyright © 2016 jqweui.io</p>
</div>