<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

    <meta name="description" content="Write an awesome description for your new site here. You can edit this line in _config.yml. It will appear in your document head meta (for Google search results) and in your feed.xml site description.
">
    <title><?php echo $__env->yieldContent('title', '首页'); ?> - 免费领纸巾</title>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('lib/weui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-weui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/demos.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>

    <?php echo $__env->yieldContent('content'); ?>

<body>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>